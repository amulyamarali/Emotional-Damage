function App() {
  return (
    <div>
      <header>
        <h2>Hello From React App 👋</h2>
      </header>
    </div>
  );
}

export default App;
